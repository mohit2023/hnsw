g++ convert.cpp -o convert
mpic++ -std=c++17 -fopenmp -o hnsw main.cpp